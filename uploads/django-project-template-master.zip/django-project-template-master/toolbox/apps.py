from django.apps import AppConfig


class ToolboxConfig(AppConfig):
    name = 'toolbox'
    verbose_name = "Toolbox"
